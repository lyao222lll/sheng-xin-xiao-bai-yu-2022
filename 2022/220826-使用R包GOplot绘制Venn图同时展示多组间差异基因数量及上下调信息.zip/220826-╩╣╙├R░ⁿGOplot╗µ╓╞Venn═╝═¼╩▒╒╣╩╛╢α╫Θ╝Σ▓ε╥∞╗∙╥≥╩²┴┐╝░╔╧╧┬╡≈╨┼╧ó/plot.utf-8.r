#读取数据，三个处理组与对照组相比获得的差异基因列表
#表中第一列为差异基因的名称，第二列中 1 代表上调，-1 代表下调
A <- read.delim('A_vs_control.txt', sep = '\t')
B <- read.delim('B_vs_control.txt', sep = '\t')
C <- read.delim('C_vs_control.txt', sep = '\t')

#绘制Venn+饼图
library(GOplot)

venn <- GOVenn(A, B, C, #三组基因列表
    label = c('A vs control', 'B vs control', 'C vs control'), #三组名称
    circle.col = c('blue', 'green', 'yellow'), #Venn 图颜色
    lfc.col = c('red', 'gray', 'green4'), #上调基因、下调基因和趋势相反基因的颜色
    plot = FALSE)  #出图的同时输出交集统计信息

venn
