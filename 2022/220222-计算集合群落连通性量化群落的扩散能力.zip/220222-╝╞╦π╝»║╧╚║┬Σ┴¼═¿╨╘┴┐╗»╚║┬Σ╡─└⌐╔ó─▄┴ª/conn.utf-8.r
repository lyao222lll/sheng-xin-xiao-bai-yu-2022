#读取示例数据
dis <- read.delim('dis.txt', row.names = 1)  #地理距离矩阵
spe <- read.delim('spe.txt', row.names = 1)  #物种丰度的 0-1 矩阵

#计算斑块连通度
patch <- names(spe)
m <- nrow(spe)
n <- ncol(spe)
con <- c()

for (i in patch) {
    ijk <- 0
    for (j in setdiff(patch, i)) {
        #exp_dij <- exp(-dis[i,j])  #active
        exp_dij <- 1 / exp(-dis[i,j])  #passive
        for (k in 1:m) {
            ijk <- ijk + spe[k,j] * exp_dij
        }
    }
    con <- c(con, (1/m) * (1/(n-1)) * ijk)
}

con <- data.frame(patch, con)
con

#计算群落连通度
ave.con <- mean(con[ ,2])
ave.con
