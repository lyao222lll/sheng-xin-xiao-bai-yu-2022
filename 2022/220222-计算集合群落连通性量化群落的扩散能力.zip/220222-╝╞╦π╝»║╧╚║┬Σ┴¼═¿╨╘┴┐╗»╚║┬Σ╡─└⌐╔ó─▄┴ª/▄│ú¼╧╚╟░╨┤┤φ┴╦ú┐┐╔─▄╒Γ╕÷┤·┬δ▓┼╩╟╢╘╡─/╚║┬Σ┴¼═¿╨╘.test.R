
  ##
  Euk <-read.delim("spe.txt",header = T,row.names = 1)
  Euk[Euk>0]=1
  dis <- read.delim("dis.txt",header = T,row.names = 1)
  #dis <- dis/100
  spe <- Euk
  #计算斑块连通度
  patch <- names(spe)
  n <- ncol(spe)
  a <- nrow(spe)
  con <- c()
  for (i in patch) {
    ijk <- 0
    for (j in setdiff(patch, i)) {
      jk <- 0
      #exp_dij <- exp(-dis[i,j])  #active
      exp_dij <- 1 / exp(-dis[i,j])  #passive
      num <- spe[,i]+spe[,j]
      num[num >0]=1
      m <- sum(num)
      for (k in 1:a) {
        jk <- jk + spe[k,j] * exp_dij
      }
     ijk <- 1/m * 1/(n-1) * jk + ijk
    }
    con <- c(con, ijk)
  }
  
  con <- data.frame(patch, con)
  con
  write.csv(con,"示例.csv")
  #计算群落连通度
  ave.con <- mean(con[ ,2])
  ave.con  