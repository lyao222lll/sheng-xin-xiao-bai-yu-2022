##相关系数计算
library(psych)

#读入分类群丰度表
taxonomy <- read.delim('tax.txt', row.names = 1, sep = '\t', stringsAsFactors = FALSE, check.names = FALSE)

#读取环境数据
env <- read.delim('env.txt', row.names = 1, sep = '\t', stringsAsFactors = FALSE, check.names = FALSE)
env <- env[rownames(taxonomy), ]

#以环境和分类群的 spearman 相关系数为例，p 值默认使用 Benjamini & Hochberg 方法校正
corr_matrix <- corr.test(taxonomy, env, method = 'spearman', adjust = 'BH')
r <- corr_matrix$r    #相关系数矩阵
p <- corr_matrix$p    #p 值矩阵

#选择显著（p<0.05）的相关系数
r_sig <- r
r_sig[p>0.05] <- 0
r <- data.frame(r)
r_sig <- data.frame(r_sig)

#将上述相关系数矩阵等整理为便于 ggplot2 作图的长列表
r$taxonomy <- rownames(r)
r <- reshape2::melt(r, id = 'taxonomy')
r$taxonomy <- factor(r$taxonomy, levels = rev(unique(r$taxonomy)))

r_sig$taxonomy <- rownames(r_sig)
r_sig <- reshape2::melt(r_sig, id = 'taxonomy')
r_sig <- subset(r_sig, value != 0)
r_sig$value <- round(r_sig$value, 2)

r <- merge(r, r_sig, by = c('taxonomy', 'variable'), all.x = TRUE)
names(r) <- c('taxonomy', 'env', 'r', 'r_sig')
head(r)  #分类群、环境变量、相关系数以及显著的相关系数


#绘制气泡图
library(ggplot2)

ggplot(r, aes(env, taxonomy)) +
geom_point(aes(color = r, size = abs(r)), na.rm = TRUE) +  #展示所有相关系数，点的大小表示相关系数的绝对值，颜色表示正负相关
scale_color_gradientn(colors = c('blue', 'gray90', 'red'), limit = c(-1, 1)) +
scale_size_continuous(range = c(0, 6), limit = c(0, 1)) +
geom_text(aes(label = r_sig), size = 3, color = 'gray') +  #并将显著的相关系数标记在图中
theme(panel.grid = element_blank(), panel.background = element_blank(), 
    axis.ticks = element_blank(), legend.key = element_blank(), 
    axis.text.x = element_text(angle = 45, hjust = 1, vjust = 1),
    plot.title = element_text(hjust = 0.5)) +
labs(y = 'Taxonomy', x = 'Environment', title = 'Spearman Correlation Plot', size = '|rho|', color = 'rho')


#绘制热图
library(ggplot2)

ggplot(r, aes(env, taxonomy)) +
geom_tile(aes(fill = r), color = 'gray') +  #展示所有相关系数，颜色代表相关系数
scale_fill_gradientn(colors = colorRampPalette(c('#2A74B2', '#A8CFE4', 'white', '#FAC4AD', '#C2383B'))(21), limit = c(-1, 1)) +
geom_text(aes(label = r_sig), size = 3, color = 'white') +  #并将显著的相关系数标记在图中
theme(axis.text.x = element_text(angle = 90, hjust = 1, vjust = 0.5),
    plot.title = element_text(hjust = 0.5)) +
scale_x_discrete(expand = c(0, 0)) + 
scale_y_discrete(expand = c(0, 0)) +
labs(y = 'Taxonomy', x = 'Environment', title = 'Spearman Correlation Plot', fill = 'rho')

