#读取序列长度统计
mrna <- read.delim('mRNA_len.txt', sep = '\t')
lncrna <- read.delim('lncRNA_len.txt', sep = '\t')

################
##使用 ggplot2 绘制频数分布直方图展示序列长度分布，以 mRNA 为例
library(ggplot2)

#使用 geom_histogram() 绘制频数分布直方图
#参数 bins 用于划分统计滑窗，或者使用 binwidth 设置滑窗步长
ggplot(data = mrna) +
geom_histogram(aes(x = length), bins = 30, color = 'gray30', fill = '#FFE8A2') +
#geom_histogram(aes(x = length), binwidth = 2500, color = 'gray30', fill = '#FFE8A2') +
theme_bw() +
labs(x = 'Length', y = 'Number of Sequences') 

#除了统计频数计数，在 geom_histogram() 中添加参数 stat(density) 也可获取密度直方图
ggplot(data = mrna) +
geom_histogram(aes(x = length, stat(density)), bins = 30, color = 'gray30', fill = '#FFE8A2') +
theme_bw() +
labs(x = 'Length', y = 'Density') 

#也可使用 geom_bar() 绘制柱形图，并使用 scale_x_binned() 控制划分统计滑窗获得频数分布直方图
ggplot(data = mrna) +
geom_bar(aes(x = length), color = 'gray30', fill = '#FFE8A2') +
scale_x_binned(n.breaks = 20) +
theme_bw() +
labs(x = 'Length', y = 'Number of Sequences') 

#如果想将 mRNA 和 lncRNA 放在一张柱形图中展示
mrna$type <- 'mRNA'
lncrna$type <- 'lncRNA'
mrna_lncrna <- rbind(mrna, lncrna)
mrna_lncrna$type <- factor(mrna_lncrna$type, levels = c('mRNA', 'lncRNA'))

ggplot(data = mrna_lncrna) +
geom_histogram(aes(x = length, fill = type), bins = 30, color = 'gray30', position = 'dodge') +
scale_fill_manual(values = c('#FFE8A2', '#8BD6FF')) +
theme_bw() +
labs(x = 'Length', y = 'Number of Sequences')

#或者以分面图呈现二者
ggplot(data = mrna_lncrna) +
geom_histogram(aes(x = length, fill = type), bins = 30, color = 'gray30', show.legend = FALSE) +
scale_fill_manual(values = c('#FFE8A2', '#8BD6FF')) +
facet_wrap(~type, scale = 'free_y', ncol = 1, strip.position = 'right') +
theme_bw() +
labs(x = 'Length', y = 'Number of Sequences')

#不过在上方左图中，mRNA 和 lncRNA 柱子之间没有空隙，影响了对统计图的观测，我试了一些参数还是难以调整
#不妨换个思路，自定义长度区间统计，并将统计值绘制柱形图展示

#首先定义长度统计范围，并预先统计各个区间内的序列总频数
length_stat <- function(x) {
	if (x <= 500) y <- '<= 500'
	else if (x > 500 & x <= 1000) y <- '501-1000'
	else if (x > 1000 & x <= 2000) y <- '1001-2000'
	else if (x > 2000 & x <= 3000) y <- '2001-3000'
	else if (x > 3000 & x <= 4000) y <- '3001-4000'
	else if (x > 4000 & x <= 5000) y <- '4001-5000'
	else if (x > 5000 & x <= 6000) y <- '5001-6000'
	else if (x > 6000 & x <= 7000) y <- '6001-7000'
	else if (x > 7000 & x <= 8000) y <- '7001-8000'
	else if (x > 8000 & x <= 9000) y <- '8001-9000'
	else if (x > 9000 & x <= 10000) y <- '9001-10000'
	else if (x > 10000) y <- '> 10000'
	y
}

mrna_lncrna$len <- apply(mrna_lncrna['length'], 1, length_stat)
mrna_lncrna$num <- 1
mrna_lncrna.stat <- aggregate(mrna_lncrna$num, by = list(mrna_lncrna$len, mrna_lncrna$type), FUN = sum)
mrna_lncrna.stat$Group.1 <- factor(mrna_lncrna.stat$Group.1, levels = c('<= 500', '501-1000', '1001-2000', '2001-3000', '3001-4000', '4001-5000', '5001-6000', '6001-7000', '7001-8000', '8001-9000', '9001-10000', '> 10000'))
head(mrna_lncrna.stat)

#将长度统计绘制为普通的柱形图展现
ggplot(mrna_lncrna.stat, aes(Group.1, x, fill = Group.2)) +
geom_col(color = 'gray30', width = 0.8, position = position_dodge(width = 0.9)) +
scale_fill_manual(values = c('#FFE8A2', '#8BD6FF')) +
theme(panel.grid = element_blank(), panel.background = element_blank(), 
    axis.line = element_line(color = 'black'), 
    axis.text.x = element_text(size = 11, angle = 45, hjust = 1)) +
scale_y_continuous(expand = expansion(mult = c(0, 0.1))) +
labs(x = 'Length', y = 'Number of Sequences', fill = NULL)

################
#默认情况下，geom_freqpoly() 绘制频数分布曲线
#该函数与 geom_histogram() 用法大致一致，参数 bins 用于划分统计滑窗，或者使用 binwidth 设置滑窗步长
ggplot(data = mrna) +
geom_freqpoly(aes(x = length), color = '#FFE8A2', bins = 50) +
#geom_freqpoly(aes(x = length), color = '#FFE8A2', binwidth  = 500) +
theme_bw() +
labs(x = 'Length', y = 'Number of Sequences')

#在 geom_freqpoly() 中添加参数 stat(density) 即可得到密度分布曲线
ggplot(data = mrna) +
geom_freqpoly(aes(x = length, stat(density)), color = '#FFE8A2', bins = 50) +
#geom_freqpoly(aes(x = length, stat(density)), color = '#FFE8A2', binwidth  = 500) +
theme_bw() +
labs(x = 'Length', y = 'Density')

#还可使用 geom_density() 或 stat_density() 绘制密度分布曲线
ggplot(data = mrna) +
#geom_density(aes(x = length), color = '#FFE8A2') +
stat_density(aes(x = length), geom = 'line', color = '#FFE8A2') +
theme_bw() +
labs(x = 'Length', y = 'Density')

#以及使用 geom_line() 绘制密度分布曲线
ggplot(data = mrna) +
geom_line(aes(x = length), stat = 'density', color = '#FFE8A2') +
theme_bw() +
labs(x = 'Length', y = 'Density') 

#将 mRNA 和 lncRNA 放在一张图中展示
#与上述直方图相比，这个直接作图的结果区分度就挺好的
ggplot(data = mrna_lncrna) +
geom_line(aes(x = length, color = type), stat = 'density', size = 1) +
scale_color_manual(values = c('#FFE8A2', '#8BD6FF')) +
theme_bw() +
labs(x = 'Length', y = 'Density', color = NULL)

#或者以分面图呈现二者
ggplot(data = mrna_lncrna) +
geom_line(aes(x = length, color = type), stat = 'density', size = 1, show.legend = FALSE) +
scale_color_manual(values = c('#FFE8A2', '#8BD6FF')) +
facet_wrap(~type, scale = 'free_y', ncol = 1, strip.position = 'right') +
theme_bw() +
labs(x = 'Length', y = 'Density')

#以前碰到文件较大的情况，难以一次读取作图
#将大文件拆分成 N 个小文件，然后逐一读取，作图，例如下
N <- 2
file_name <- c('mRNA_len.txt', 'lncRNA_len.txt')
line_color <- c('#FFE8A2', '#8BD6FF')

p <- ggplot()
for (i in 1:N) {
	plot_data <- read.delim(file_name[i])
	p <- p + geom_density(data = plot_data, aes(x = length), color = line_color[i])
}
p
