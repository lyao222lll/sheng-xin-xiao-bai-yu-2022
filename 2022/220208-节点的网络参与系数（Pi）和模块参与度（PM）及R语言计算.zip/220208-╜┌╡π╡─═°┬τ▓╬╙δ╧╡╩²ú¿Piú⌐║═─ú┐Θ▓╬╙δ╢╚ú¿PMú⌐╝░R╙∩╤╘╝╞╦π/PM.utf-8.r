#定义函数计算 Pi
#kiS 为节点 i 与模块 S 中节点的边数
#ki 是节点 i 的总边数
Pi <- function(adj_matrix, nodes_list) {
    Pi <- NULL
    NM <- unique(nodes_list$module)
    
    for (i in rownames(nodes_list)) {
        ki <- nodes_list[i,'degree']
        kiS_ki = 0
        
        for (S in NM) {
            S <- subset(nodes_list, module == S)
            i_S <- adj_matrix[i,rownames(S)]
            i_S[i_S != 0] <- 1
            kiS <- sum(i_S)
            kiS_ki = kiS_ki + (kiS/ki)^2
        }
        
        Pi <- c(Pi, 1 - kiS_ki)
    }
    
    Pi <- as.data.frame(Pi)
    rownames(Pi) <- rownames(nodes_list)
    Pi
}

#定义函数计算 PM
#kim 是节点 i 与模块 m 中节点的边数
#ki 是节点 i 的总边数
PM <- function(adj_matrix, nodes_list) {
    PM <- NULL
    NM <- unique(nodes_list$module)
    
    for (i in rownames(nodes_list)) {
        ki <- nodes_list[i,'degree']
        PM_i <- c()
        
        for (S in NM) {
            S <- nodes_list[which(nodes_list$module == S), ]
            i_S <- adj_matrix[i,rownames(S)]
            i_S[i_S != 0] <- 1
            kim <- sum(i_S)
            PM_i <- c(PM_i, kim/ki)
        }
        
        PM <- rbind(PM, PM_i)
    }
    
    PM <- as.data.frame(PM)
    rownames(PM) <- rownames(nodes_list)
    colnames(PM) <- NM
    PM
}

#读取邻接矩阵，数值“1”表示存在互作，“0”表示无互作
adj_matrix <- read.delim('net_adj.txt', row.names = 1, sep = '\t', check.names = FALSE)

#节点属性列表，包含节点名称、节点度（以“degree”命名该列）以及该节点所处的模块（以“module”命名该列）
nodes_list <- read.delim('nodes_list.txt', sep = '\t', row.names = 1, check.names = FALSE)

#指定邻接矩阵，节点属性列表计算 Pi 和 PM
net_Pi <- Pi(adj_matrix, nodes_list)
head(net_Pi)  #各节点及其 Pi 值

net_PM <- PM(adj_matrix, nodes_list)
head(net_PM)  #各节点（行）在各模块（列）的 PM 值

#输出
#write.table(net_Pi, 'net_Pi.txt', sep = '\t', col.names = NA, quote = FALSE)
#write.table(net_PM, 'net_PM.txt', sep = '\t', col.names = NA, quote = FALSE)

