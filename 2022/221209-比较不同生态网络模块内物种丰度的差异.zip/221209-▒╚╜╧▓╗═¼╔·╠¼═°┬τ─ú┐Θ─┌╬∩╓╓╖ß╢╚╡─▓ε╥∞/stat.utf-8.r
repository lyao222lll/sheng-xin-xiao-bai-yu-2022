#读取 OTU 丰度表、样本分组和网络模块数据
otu <- read.delim('otu_table.txt')
group <- read.delim('group.txt')
module <- read.delim('node_module.txt')

#合并数据集
otu <- reshape2::melt(otu, id = 'otu')
names(otu) <- c('otu', 'sample', 'relative_abundance')
otu <- merge(otu, module, by = 'otu')
otu <- merge(otu, group, by = 'sample')
otu$module <- as.character(otu$module)
otu$group <- factor(otu$group)
head(otu)  #合并后的 OTU 在各样本的丰度、OTU 所属模块以及样本分组

#绘制绘制箱线图分别展示各模块各组微生物丰度的整体分布
library(ggplot2)

p <- ggplot(otu, aes(group, relative_abundance)) +
geom_boxplot(aes(fill = module), show.legend = FALSE) +
facet_wrap(~module, ncol = 3, scale = 'free_y') +
theme(panel.grid = element_blank(), panel.background = element_rect(color = 'black', fill = 'white')) +
scale_y_continuous(expand = expansion(mult = c(0.1, 0.3))) +
labs(x = 'Group', y = 'Relative Abundance')

p

#各模块内不同组物种丰度的差异比较（本示例图省事儿直接使用 Tukey test，实际情况中慎重选择统计检验方法！）
library(multcomp)

stat <- NULL
for (i in unique(otu$module)) {
    otu_i <- subset(otu, module == i)
    fit <- aov(relative_abundance~group, otu_i)
    tuk <- cld(glht(fit, alternative = 'two.sided', linfct = mcp(group = 'Tukey')), decreasing = TRUE)
    relative_abundance <- aggregate(otu_i$relative_abundance, by = list(otu_i$group), FUN = max)
    stat <- rbind(stat, data.frame(module = i, group = names(tuk$mcletters$Letters), relative_abundance = relative_abundance$x, sig = tuk$mcletters$Letters))
}

p + geom_text(data = stat, aes(label = sig), vjust = -1.5)
