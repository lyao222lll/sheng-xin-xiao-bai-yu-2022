#读取两个网络邻接矩阵数据
net_adj1 <- read.csv('network.adj1.csv', row.names = 1, check.names = FALSE)
net_adj2 <- read.csv('network.adj2.csv', row.names = 1, check.names = FALSE)

#邻接矩阵 -> igraph 的邻接列表，获得无向网络
library(igraph)

g1 <- graph_from_adjacency_matrix(as.matrix(net_adj1), mode = 'undirected')
g2 <- graph_from_adjacency_matrix(as.matrix(net_adj2), mode = 'undirected')

#提取两个网络的节点和边名称
g1_node <- attributes(V(g1))$names
g2_node <- attributes(V(g2))$names
g1_edge <- attributes(E(g1))$vnames
g2_edge <- attributes(E(g2))$vnames

#通过交集和差集方法，计算两个网络间的特有节点、特有边、共享节点和共享边
node_shared <- intersect(g1_node, g2_node)
edge_shared <- intersect(g1_edge, g2_edge)
node_unique_g1 <- setdiff(g1_node, node_shared)
node_unique_g2 <- setdiff(g2_node, node_shared)
edge_unique_g1 <- setdiff(g1_edge, edge_shared)
edge_unique_g2 <- setdiff(g2_edge, edge_shared)

length(node_shared)  #两个网络的共享节点数量
length(edge_shared)  #两个网络的共享边数量
length(node_unique_g1)  #网络1的特有节点数量
length(node_unique_g2)  #网络2的特有节点数量
length(edge_unique_g1)  #网络1的特有边数量
length(edge_unique_g2)  #网络2的特有边数量

#根据上文 Timotheé et al (2012) 的网络相异度公式，计算两个网络的生态差异（βw）
a <- length(edge_shared)
b <- length(edge_unique_g1)
c <- length(edge_unique_g2)
bw <- (a+b+c)/((2*a+b+c)/2)-1
bw
