#Bioconductor 安装 clusterProfiler
BiocManager::install('clusterProfiler')

#### MSigDB GSEA
library(clusterProfiler)

#读取基因列表（包含基因名称以及 log2 转化后的 Fold Change 信息）
gene_human <- read.delim('gene_human.txt', stringsAsFactors = FALSE)

genelist <- gene_human$log2FoldChange
names(genelist) <- gene_human$gene_id

#GSEA 之前，需要对所有基因根据 log2 Fold Change 由高到低排个序
genelist <- genelist[order(genelist, decreasing = TRUE)]

#读取基因集（本示例使用的 MSigDB 数据库中的 C5 ontology gene sets）
c5_gmt <- read.gmt('c5.all.v2022.1.Hs.symbols.txt')

#GSEA，详情 ?GSEA
gsea <- GSEA(genelist,  #待富集的基因列表
    TERM2GENE = c5_gmt,  #基因集
    pvalueCutoff = 1,  #指定 p 值阈值（可指定 1 以输出全部）
    pAdjustMethod = 'BH')  #指定 p 值校正方法

#输出
write.table(gsea, 'gsea_human_c5.txt', sep = '\t', row.names = FALSE, quote = FALSE)

#可以使用 clusterProfiler 包里的一些默认作图方法进行简单可视化，例如
dotplot(gsea)  #富集气泡图
gseaplot(gsea, 'GOBP_ADAPTIVE_IMMUNE_RESPONSE')  #指定特定功能后展示基因集富集得分图

#### 自定义的 GSEA
library(clusterProfiler)

#读取基因列表（包含基因名称以及 log2 转化后的 Fold Change 信息）
gene_express <- read.delim('gene_express.txt', stringsAsFactors = FALSE)

genelist <- gene_express$log2FoldChange
names(genelist) <- gene_express$gene_id

#GSEA 之前，需要对所有基因根据 log2 Fold Change 由高到低排个序
genelist <- genelist[order(genelist, decreasing = TRUE)]

#读取自定义的基因集（包含背景基因名称和功能信息）
gene_GO <- read.delim('gene_GO.txt', stringsAsFactors = FALSE)

#GSEA，详情 ?GSEA
#由于上述自定义基因集使用的 GO 注释，因此这里执行了 GO 的 GSEA
gsea <- GSEA(genelist,  #待富集的基因列表
    TERM2GENE = gene_GO[c('ID', 'gene_id')],  #基因集
    TERM2NAME = gene_GO[c('ID', 'Description')], 
    pvalueCutoff = 1,  #指定 p 值阈值（可指定 1 以输出全部）
    pAdjustMethod = 'BH')  #指定 p 值校正方法

#输出
write.table(gsea, 'gsea_GO.txt', sep = '\t', row.names = FALSE, quote = FALSE)

#再把 GO Ontology 信息添加在上述 GO 富集结果中
tmp <- read.delim('gsea_GO.txt')
gene_GO <- gene_GO[!duplicated(gene_GO$ID), ]
tmp <- merge(tmp, gene_GO[c('ID', 'ONTOLOGY')], by = 'ID')
tmp <- tmp[c(12, 1:11)]
tmp <- tmp[order(tmp$pvalue), ]

#输出
write.table(tmp, 'gsea_GO.add_Ontology.txt', sep = '\t', row.names = FALSE, quote = FALSE)

#同上文提到的，clusterProfiler 包里的一些默认作图方法，例如
dotplot(gsea)  #富集气泡图
gseaplot(gsea, 'GO:0004386')  #指定特定功能后展示基因集富集得分图
