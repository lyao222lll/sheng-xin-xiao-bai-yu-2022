library(ggplot2)

#读取数据
dat <- read.delim('爆发词及其频次统计表.txt')

#整理表格数据为 ggplot2 作图结构
plot_data <- NULL
for (i in 1:nrow(dat)) {
	Year <- seq(dat[i,'Begin'], dat[i,'End']-1)
	plot_i <- data.frame(Year, Strength = dat[i,'Strength'], Key.Words = dat[i,'Key.Words'])
	plot_data <- rbind(plot_data, plot_i)
}

#可以按出现时间给关键词排个序，画图好看些......
dat <- dat[order(dat$Begin), ]
plot_data$Key.Words <- factor(plot_data$Key.Words, levels = unique(dat$Key.Words))

#对爆发词及其频次进行可视化
ggplot(plot_data, aes(Year, Key.Words, fill = Strength)) +
geom_tile() +  #绘制热图，由于没有数据的地方颜色为空，所以连续的色块就可以表示时间及频率信息了
scale_fill_gradientn(colours = colorRampPalette(c('#EEE129', '#7FB65D', '#228687', '#304F71', '#410857'))(20)) +  #词频的渐变颜色
theme_bw() +
theme(panel.grid.minor = element_blank(),
    axis.text.x = element_text(angle = 45, hjust = 1, vjust = 1)) +
scale_x_continuous(
    breaks = seq(min(plot_data$Year), max(plot_data$Year)+1)-0.5, 
    labels = seq(min(plot_data$Year), max(plot_data$Year)+1)) +
labs(x = 'Year', y = 'Key Words', fill = 'Strength')

ggplot(plot_data, aes(Year, Key.Words, fill = Strength)) +
geom_tile() + 
scale_fill_gradientn(colours = colorRampPalette(c('#EEE129', '#7FB65D', '#228687', '#304F71', '#410857'))(20)) +  #词频的渐变颜色
theme( panel.background = element_blank(), panel.grid = element_blank(), 
    axis.line = element_line(), axis.text.x = element_text(angle = 45, hjust = 1, vjust = 1)) +
scale_x_continuous(
    breaks = seq(min(plot_data$Year), max(plot_data$Year)+1)-0.5, 
    labels = seq(min(plot_data$Year), max(plot_data$Year)+1)) +
labs(x = 'Year', y = 'Key Words', fill = 'Strength')

