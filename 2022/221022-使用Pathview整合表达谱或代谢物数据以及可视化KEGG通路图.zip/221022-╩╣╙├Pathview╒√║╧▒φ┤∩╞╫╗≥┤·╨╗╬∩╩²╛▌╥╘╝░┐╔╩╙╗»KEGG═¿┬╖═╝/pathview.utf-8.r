#通过 Bioconductor 安装 pathview 包
#install.packages('BiocManager')
#BiocManager::install('pathview')

#加载 pathview 包
library(pathview)

#读取示例数据
gene_data <- read.delim('gene_data.txt', row.names = 1)
compound_data <- read.delim('compound_data.txt', row.names = 1)

#将基因或代谢物映射至指定的 KEGG 通路图中
#以下仅显示了基本选项，更多细节等参阅帮助文档 ?pathview
p <- pathview(
	gene.data = gene_data,  #基因列表
	gene.idtype = 'entrez',  #指定基因名称类型，本示例使用的 ENTREZ ID
	cpd.data = compound_data,  #代谢物列表
	cpd.idtype = "kegg",  #指定代谢物名称类型，本示例使用的 KEGG ID
	species = 'hsa',  #指定物种，本示例数据来自智人
	kegg.native = TRUE,  #为 TRUE 时输出 png 位图，为 FALSE 时输出 pdf 矢量图
	pathway.id = c('05016', '04921')  #指定待映射的 KEGG 通路 ID，可批量指定多个
)

#如果只关注其中的一种，比方说只关注基因，不使用代谢物数据
#此时只输入基因数据作图即可
gene_data <- read.delim('gene_data.txt', row.names = 1)

p <- pathview(
	gene.data = gene_data,  #基因列表
	species = 'hsa',  #指定物种，本示例数据来自智人
	kegg.native = TRUE,  #为 TRUE 时输出 png 位图，为 FALSE 时输出 pdf 矢量图
	pathway.id = c('05016', '04921')  #指定待映射的 KEGG 通路 ID，可批量指定多个
)

###多组数据的演示
#读取示例数据
gene_data <- read.delim('gene_data.3group.txt', row.names = 1)  #3 组的差异基因
compound_data <- read.delim('compound_data.2group.txt', row.names = 1)  #2 组的差异代谢物

#将基因或代谢物映射至指定的 KEGG 通路图中
#以下仅显示了基本选项，更多细节等参阅帮助文档 ?pathview
p <- pathview(
	gene.data = gene_data,  #基因列表
	gene.idtype = 'entrez',  #指定基因名称类型，本示例使用的 ENTREZ ID
	cpd.data = compound_data,  #代谢物列表
	cpd.idtype = "kegg",  #指定代谢物名称类型，本示例使用的 KEGG ID
	species = 'hsa',  #指定物种，本示例数据来自智人
	kegg.native = TRUE,  #为 TRUE 时输出 png 位图，为 FALSE 时输出 pdf 矢量图
	pathway.id = c('05016', '04921')  #指定待映射的 KEGG 通路 ID，可批量指定多个
)
