#读取 OTU 丰度表和样本分组
otu <- read.delim('otu_table.txt', row.names = 1, stringsAsFactors = FALSE)
group <- read.delim('group.txt', row.names = 1, stringsAsFactors = FALSE)

##计算各组样本中，OTU 的特异性（specificity）和占有率（occupancy）

Nindividuals_S <- rep(0, nrow(otu))
for (i in unique(group$Group)) {
	otu_group_i <- otu[ ,rownames(subset(group, Group == i))]
	Nindividuals_S <- Nindividuals_S + rowMeans(otu_group_i)  #计算 Nindividuals S
}

spec_occu <- NULL
for (i in unique(group$Group)) {
	otu_group_i <- otu[ ,rownames(subset(group, Group == i))]
	Nindividuals_SH <- apply(otu_group_i, 1, mean)  #计算 Nindividuals SH
	Specificity <- Nindividuals_SH / Nindividuals_S  #计算 Specificity
	Nsites_H <- ncol(otu_group_i)  #计算 Nsites H
	Nsites_SH <- apply(otu_group_i, 1, function(x) sum(x>0))  #计算 Nsites SH
	Occupancy <- Nsites_SH / Nsites_H  #计算 Occupancy
	spec_occu_group_i <- data.frame(Group = i, OTU = rownames(otu_group_i), Specificity = Specificity, Occupancy = Occupancy, Abundance_mean = rowMeans(otu_group_i), Taxonomy = otu$Taxonomy)
	spec_occu <- rbind(spec_occu, spec_occu_group_i)  #合并各组统计
}
head(spec_occu)  #该数据框包含各组中各 OTU 的名称、特异性、占有率、平均丰度、类群信息等

#输出统计表格
#write.table(spec_occu, 'spec_occu.txt', row.names = FALSE, sep = '\t', quote = FALSE)

#绘制 SPEC-OCCU 图
library(ggplot2)

p <- ggplot(spec_occu, aes(Occupancy, Specificity)) +
geom_point(aes(size = log10(Abundance_mean), color = Taxonomy)) +
#geom_jitter(aes(size = log10(Abundance_mean), color = Taxonomy)) +  #如果觉得普通散点图中的点重叠严重不好看，可以仿照 Gweon et al (2021) 使用抖动点图来展示
scale_size(breaks = c(-1, -2, -3, -4), labels = c(expression(10^{-1}), expression(10^{-2}), expression(10^{-3}), expression(10^{-4})), range = c(0, 4)) +
scale_color_manual(values = c('#E7272E', '#F59D1F', '#768CC5', '#9BC648', '#794779', '#A19E9D'), limits = c('Proteobacteria', 'Actinobacteria', 'Acidobacteria', 'Bacteroidetes', 'Firmicutes', 'Others')) +
theme(panel.grid = element_blank(), panel.background = element_rect(fill = 'white', color = 'gray30'), legend.key = element_blank()) +
facet_wrap(~Group, ncol = 2) +
scale_x_continuous(breaks = c(0, 0.5, 1), expand = c(0, 0), limit = c(0, 1)) +
scale_y_continuous(breaks = c(0, 0.5, 1), expand = c(0, 0), limit = c(0, 1)) +
labs(x = 'Occupancy', y = 'Specificity', size = 'Average relative abundance', color = 'Taxonomy') +
coord_cartesian(clip = 'off')

p

##识别各组样本中的特化种（specialist species）

#在上述统计表格中直接根据特异性和占有率 ≥0.7 做筛选，保留下的 OTU 即为特化种
spec_occu_specialist <- subset(spec_occu, Specificity >= 0.7 & Occupancy >= 0.7)
head(spec_occu_specialist)

#输出统计表格
#write.table(spec_occu_specialist, 'spec_occu_specialist.txt', row.names = FALSE, sep = '\t', quote = FALSE)

#在上述 SPEC-OCCU 图中添加阈值线
p + 
geom_segment(aes(x = 0.7, xend = 1, y = 0.7, yend = 0.7), linetype = 2)+
geom_segment(aes(x = 0.7, xend = 0.7, y = 0.7, yend = 1), linetype = 2)

