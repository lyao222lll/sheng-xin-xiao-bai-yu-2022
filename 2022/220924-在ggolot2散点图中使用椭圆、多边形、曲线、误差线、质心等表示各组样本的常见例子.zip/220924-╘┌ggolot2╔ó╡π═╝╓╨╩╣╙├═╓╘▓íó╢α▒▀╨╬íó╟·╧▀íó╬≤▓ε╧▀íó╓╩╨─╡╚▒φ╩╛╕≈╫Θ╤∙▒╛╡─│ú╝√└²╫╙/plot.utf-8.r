#加载 ggplot2 包，读取做图数据
library(ggplot2)

plot_data <- read.delim('plot_data.txt', stringsAsFactors = FALSE)

#绘制散点图展示所有样本的两个变量的分布（Var1 和 Var2）
#并使用不同颜色或形状的散点表示样本分组，例如
p <- ggplot(plot_data, aes(Var1, Var2)) +
theme(panel.background = element_rect(color = 'black', fill = 'transparent'), 
    panel.grid = element_blank(), legend.key = element_blank(), 
    axis.text = element_text(color = 'black'), axis.ticks = element_line(color = 'black')) +
labs(x = 'Var1', y = 'Var2')

p +
geom_point(aes(color = Group)) +
scale_color_manual(values = c('#DC1A1B', '#1E74AE', '#319A2A'))

p +
geom_point(aes(color = Group, shape = Group)) +
scale_color_manual(values = c('#DC1A1B', '#1E74AE', '#319A2A')) +
scale_shape_manual(values = c(15, 16, 17))

#添加置信椭圆，注意它不是聚类
#以下以 95% 置信区间为例
p + 
stat_ellipse(aes(color = Group), level = 0.95, linetype = 2, show.legend = FALSE) +
geom_point(aes(color = Group)) +
scale_color_manual(values = c('#DC1A1B', '#1E74AE', '#319A2A'))

p + 
stat_ellipse(aes(color = Group), level = 0.95, show.legend = FALSE) +
geom_point(aes(color = Group)) +
scale_color_manual(values = c('#DC1A1B', '#1E74AE', '#319A2A'))

p + 
stat_ellipse(aes(fill = Group), geom = 'polygon', level = 0.95, alpha = 0.1, show.legend = FALSE) +
scale_fill_manual(values = c('#DC1A1B', '#1E74AE', '#319A2A')) +
geom_point(aes(color = Group)) +
scale_color_manual(values = c('#DC1A1B', '#1E74AE', '#319A2A'))

#计算各组样本的边界
library(plyr)

border <- ddply(plot_data, 'Group', function(df) df[chull(df[[2]], df[[3]]), ])

#将边界点连接为多边形表示样本分组，例如
p + 
geom_polygon(data = border, aes(color = Group), fill = 'transparent', show.legend = FALSE) +
geom_point(aes(color = Group)) +
scale_color_manual(values = c('#DC1A1B', '#1E74AE', '#319A2A'))

p + 
geom_polygon(data = border, aes(fill = Group), alpha = 0.1, show.legend = FALSE) +
scale_fill_manual(values = c('#DC1A1B', '#1E74AE', '#319A2A')) +
geom_point(aes(color = Group)) +
scale_color_manual(values = c('#DC1A1B', '#1E74AE', '#319A2A'))

#不规则曲线表示样本分组，例如
library(ggalt)

p + 
geom_encircle(aes(color = Group), show.legend = FALSE) +
geom_point(aes(color = Group)) +
scale_color_manual(values = c('#DC1A1B', '#1E74AE', '#319A2A'))

p + 
geom_encircle(aes(fill = Group, color = Group), alpha = 0.1, show.legend = FALSE) +
scale_fill_manual(values = c('#DC1A1B', '#1E74AE', '#319A2A')) +
geom_point(aes(color = Group)) +
scale_color_manual(values = c('#DC1A1B', '#1E74AE', '#319A2A'))

#通过 annotate() 添加样本分组标签
#以上文的 95% 置信椭圆的情况为例来展示
p + 
stat_ellipse(aes(fill = Group), geom = 'polygon', level = 0.95, alpha = 0.1) +
scale_fill_manual(values = c('#DC1A1B', '#1E74AE', '#319A2A')) +
geom_point(aes(color = Group)) +
scale_color_manual(values = c('#DC1A1B', '#1E74AE', '#319A2A')) +
theme(legend.position = 'none') +
annotate('text', label = 'A', x = -3, y = 1, size = 5, colour = '#DC1A1B') +
annotate('text', label = 'B', x = 1, y = 3.5, size = 5, colour = '#1E74AE') +
annotate('text', label = 'C', x = 3, y = -1.5, size = 5, colour = '#319A2A')


#计算各组均值（mean）、标准差（sd）、标准误差（se）、95% 置信区间（conf_95）等
library(doBy)

se <- function(x) sd(x)/sqrt(length(x))
conf_95 <- function(x) t.test(x, conf.level = 0.95)$conf.int[2]
stat <- summaryBy(Var1+Var2~Group, plot_data, FUN = c(mean, sd, se, conf_95))

#以均值±标准差（mean±sd）的形式来表示各组样本的整体情况，例如
p <- ggplot(stat, aes(x = Var1.mean, y = Var2.mean, color = Group)) +
geom_point() +
theme(panel.background = element_rect(color = 'black', fill = 'transparent'), 
    panel.grid = element_blank(), legend.key = element_blank(), 
    axis.text = element_text(color = 'black'), axis.ticks = element_line(color = 'black')) +
labs(x = 'Var1', y = 'Var2')

p +
geom_errorbarh(aes(xmin = Var1.mean + Var1.sd, xmax = Var1.mean - Var1.sd), height = 0.15) +
geom_errorbar(aes(ymin = Var2.mean + Var2.sd, ymax = Var2.mean - Var2.sd), width = 0.15) +
scale_color_manual(values = c('#DC1A1B', '#1E74AE', '#319A2A'))

p +
geom_linerange(aes(xmin = Var1.mean + Var1.sd, xmax = Var1.mean - Var1.sd)) +
geom_linerange(aes(ymin = Var2.mean + Var2.sd, ymax = Var2.mean - Var2.sd)) +
scale_color_manual(values = c('#DC1A1B', '#1E74AE', '#319A2A'))

#均值±标准误差（mean±se）的示例
p +
geom_linerange(aes(xmin = Var1.mean + Var1.se, xmax = Var1.mean - Var1.se)) +
geom_linerange(aes(ymin = Var2.mean + Var2.se, ymax = Var2.mean - Var2.se)) +
scale_color_manual(values = c('#DC1A1B', '#1E74AE', '#319A2A'))

#均值±95% 置信区间（mean±conf_95）的示例
p +
geom_linerange(aes(xmin = Var1.mean + Var1.conf_95, xmax = Var1.mean - Var1.conf_95)) +
geom_linerange(aes(ymin = Var2.mean + Var2.conf_95, ymax = Var2.mean - Var2.conf_95)) +
scale_color_manual(values = c('#DC1A1B', '#1E74AE', '#319A2A'))

#各组样本与质心的连线
#对于质心点，本示例直接使用各组的均值，已经在上一步中计算得到
plot_data <- merge(plot_data, stat, by = 'Group')

p <- ggplot(plot_data) +
geom_segment(aes(x = Var1.mean, y = Var2.mean, xend = Var1, yend = Var2, color = Group), show.legend = FALSE) +
geom_point(aes(x = Var1, y = Var2, color = Group)) +
scale_color_manual(values = c('#DC1A1B', '#1E74AE', '#319A2A')) +
theme(panel.background = element_rect(color = 'black', fill = 'transparent'), 
    panel.grid = element_blank(), legend.key = element_blank(), 
    axis.text = element_text(color = 'black'), axis.ticks = element_line(color = 'black')) +
labs(x = 'Var1', y = 'Var2')

p

#在质心处添加一个大点
p +
geom_point(data = stat, aes(x = Var1.mean, y = Var2.mean, color = Group), size = 3, show.legend = FALSE)

#不妨再添加一个 95% 置信椭圆
p + 
geom_point(data = stat, aes(x = Var1.mean, y = Var2.mean, color = Group), size = 3, show.legend = FALSE) +
stat_ellipse(aes(x = Var1, y = Var2, color = Group), level = 0.95, show.legend = FALSE)

#或者在质心点位置添加样本分组标签
p +
geom_point(data = stat, aes(x = Var1.mean, y = Var2.mean, color = Group), shape = 22, fill = 'white', size = 4, show.legend = FALSE) +
geom_text(data = stat, aes(x = Var1.mean, y = Var2.mean, color = Group, label = Group), size = 3, show.legend = FALSE) +
stat_ellipse(aes(x = Var1, y = Var2, color = Group), level = 0.95, show.legend = FALSE) +
theme(legend.position = 'none')
