library(ggplot2)
library(ggrepel)  #用于添加样本标签
library(maps)  #用于载入一个世界地图模板

#读取示例的站点经纬度坐标
site <- read.delim('site.txt')

#绘制世界地图的简图
p <- ggplot() +
geom_polygon(data = map_data('world'), aes(x = long, y = lat, group = group), fill = 'gray70') +  #世界地图模板
theme_bw() +  #以下用于修改主题、配色、坐标轴等
theme(panel.grid.minor = element_blank()) +
scale_x_continuous(breaks = c(-150, -100, -50, 0, 50, 100, 150), expand = c(0, 0), 
    labels = c('150°W', '100°W', '50°W', '0', '50°E', '100°E', '150°E')) +
scale_y_continuous(breaks = c(-60, -30, 0, 30, 60), expand = c(0, 0), 
    labels = c('60°S', '30°S', '0', '30°N', '60°N')) +
labs(x = 'Longitude', y = 'Latitude', color = 'ocean and sea regions')

p

#绘制采样站点的地图
p1 <- p +
geom_polygon(data = map_data('world'), aes(x = long, y = lat, group = group), fill = 'gray70') +  #世界地图模板
geom_point(data = site, aes(x = Longitude, y = Latitude, color = Ocean.and.sea.regions), size = 2) +  #将数据中的样本点绘制在地图中
#geom_label_repel(data = site, aes(x = Longitude, y = Latitude, label = Station.identifier), size = 2, show.legend = FALSE) +  #添加样本标签
scale_color_manual(values = c('#F99233', '#3CA6CC', '#01B250', '#1F5897', '#C1453D', '#8BC847', '#91B1D0', '#050607'))

p1

p2 <- p +
geom_polygon(data = map_data('world'), aes(x = long, y = lat, group = group), fill = 'gray70') +  #世界地图模板
geom_point(data = site, aes(x = Longitude, y = Latitude), color = 'black') +  #将数据中的样本点绘制在地图中
geom_label_repel(data = site, color = 'white', segment.colour = 'black', 
    aes(x = Longitude, y = Latitude, label = Station.identifier, fill = Ocean.and.sea.regions)) +  #添加样本标签
scale_fill_manual(values = c('#F99233', '#3CA6CC', '#01B250', '#1F5897', '#C1453D', '#8BC847', '#91B1D0', '#050607'))

p2

#如要从中截取部分展示
#比如说图中没有东太平洋的采样点，因此只展示 180°W~100°E 的区域
p1 + coord_cartesian(xlim = c(-180, 100))
