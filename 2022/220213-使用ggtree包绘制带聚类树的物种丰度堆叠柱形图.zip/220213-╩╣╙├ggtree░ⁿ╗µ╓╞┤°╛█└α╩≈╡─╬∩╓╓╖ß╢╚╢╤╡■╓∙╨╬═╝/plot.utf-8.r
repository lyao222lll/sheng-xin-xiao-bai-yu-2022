#安装 ggtree 包
#install.packages('BiocManager')
#BiocManager::install('ggtree')

library(ggtree)
library(ggplot2)

#读取分类群丰度表
taxo <- read.delim('phylum_top10.txt', row.names = 1, sep = '\t')

#首先根据分类群丰度计算样本间距离
#本示例以群落分析中常用的 Bray-curtis 距离为例，使用 vegan 包函数 vegdist() 计算
dis_bray <- vegan::vegdist(t(taxo), method = 'bray')

#根据距离矩阵执行层次聚类，本示例以 UPGMA 为例
tree <- hclust(dis_bray, method = 'average')
tree

#使用 ggtree 包提供的方法绘制一个简单的聚类树用作展示
ggtree(tree) +  #聚类树
geom_tippoint(size = 2) +  #添加节点
geom_tiplab(hjust = -0.5) + #添加名称
theme_tree2()  #添加刻度线

#转换树文件格式，便于添加分组
tree <- ape::as.phylo(tree)

#读取样本分组并将分组信息添加在聚类树中
group <- read.delim('group.txt', row.names = 1, sep = '\t')
group <- split(row.names(group), group$groups)

p <- ggtree(groupOTU(tree, group), aes(color = group), size = 1) + 
geom_tippoint(size = 2, show.legend = FALSE) +  #添加节点
geom_tiplab(hjust = -0.5, show.legend = FALSE) +  #添加名称
theme_tree2() +  #添加刻度线
xlim_tree(0.13)  #可以控制聚类树长度范围

p

#在聚类树的右侧添加分类群丰度的堆叠柱形图
taxo$taxonomy <- factor(rownames(taxo), levels = rev(rownames(taxo)))
taxo <- reshape2::melt(taxo, id = 'taxonomy')
taxo <- taxo[c(2, 3, 1)]
head(taxo)  #注：作图数据的第一列必须为样本名称

p2 <- p + 
geom_facet(panel = 'Relative abundance (%)', data = taxo, geom = geom_bar, 
    mapping = aes(x = 100 * value, fill = taxonomy), color = 'gray30', 
    orientation = 'y', width = 0.8, stat = 'identity') +  #绘制分类群丰度堆叠图
scale_fill_manual(values = c('gray', '#CCEBC5', '#BC80BD', '#FCCDE5', '#B3DE69', '#FDB462', 
    '#80B1D3', '#FB8072', '#BEBADA', '#FFFFB3', '#8DD3C7'))  #赋值分类群颜色

facet_widths(p2, widths = c(1, 2))  #R文档上说可以用该函数控制组合图中各组分的宽度，但似乎没反应？


#小问题，俺也不知为什么画出来的和网上教程中不一样......
#facet_plot() 这个函数有 bug 吗？还是我运行方式不对......
#R 代码来源：https://www.r-bloggers.com/2016/12/add-layer-to-specific-panel-of-facet_plot-output-2/
library(dplyr)
library(ggstance)
library(ggtree)
tr <- rtree(30)
p <- ggtree(tr) + theme_tree2() 
df <- data.frame(id = rep(tr$tip.label, each=2),
    value = abs(rnorm(60, mean=100, sd=50)),
    category = rep(LETTERS[1:2], 30))
sum_value <- df %>%
    group_by(id) %>%
    summarize(total = sum(value))
p2 <- facet_plot(p, panel = 'Stacked Barplot', 
    data = df, geom = geom_bar,
    mapping = aes(x = value, fill = as.factor(category)),
    stat='identity' ) 
facet_plot(p2, panel='Stacked Barplot',
    data=sum_value, geom=geom_text, 
    mapping=aes(x=total+20, label=round(total)))

